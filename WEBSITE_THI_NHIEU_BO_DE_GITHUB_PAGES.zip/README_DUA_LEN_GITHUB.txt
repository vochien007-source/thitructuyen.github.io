1. Giải nén gói ZIP này.
2. Tải file index.html và thư mục de lên kho GitHub Pages.
3. Đảm bảo index.html nằm ở thư mục gốc của repository.
4. Link từng đề nằm tại: /de/<ma-de>/
